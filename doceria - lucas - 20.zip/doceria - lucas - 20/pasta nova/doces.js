document.getElementById("beijinho")
document.getElementById("bolo")
document.getElementById("brigadeiro")
document.getElementById("pudim")


function somar(){

let quantidade = Number (document.getElementById('beijinho').value)
let quantidade2 = Number (document.getElementById('bolo').value)
let quantidade3 = Number (document.getElementById('brigadeiro').value)
let quantidade4 = Number (document.getElementById('pudim').value)

let valor = (10.50)
let valor2 = (10.50)
let valor3 = (10.50)
let valor4 = (10.50)

const soma = (quantidade + quantidade2 + quantidade3 + quantidade4)

const fim =  (quantidade*valor) + (quantidade2*valor2) + (quantidade3*valor3) + (quantidade4*valor4)

doces1.innerHTML = soma
valornovo.innerHTML = fim

}

button.addEventListener("click", somar)